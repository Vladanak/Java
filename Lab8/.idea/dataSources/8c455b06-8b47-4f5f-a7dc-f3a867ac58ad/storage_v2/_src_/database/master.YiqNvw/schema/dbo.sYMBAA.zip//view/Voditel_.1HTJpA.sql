CREATE VIEW  [Водитель]
	as select Код_водителя_ФИО,Стаж  from Водители
	    where  Стаж>4 WITH CHECK OPTION;
GO

